=== GdeSlon Begi Affiliate Shop ===
Contributors: gdeslon
Donate link: http://gdeslon.ru/
Tags: two-columns, right-sidebar, fixed-width, white, threaded-comments, sticky-post,theme-options
Requires at least: 3.4.1
Tested up to: 3.4.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

GdeSlon Begi Affiliate Shop is clean and simple theme for affiliate shop, created to work with
<a href="http://wordpress.org/extend/plugins/gdeslon-affiliate-shop/">GdeSlon Affiliate Shop plugin</a>
based on <a href="http://dukapress.com/blog/2011/02/05/begi-wordpress-e-commerce-theme/">Begi theme</a>.

== Changelog ==

= 1.0 =
* First public version