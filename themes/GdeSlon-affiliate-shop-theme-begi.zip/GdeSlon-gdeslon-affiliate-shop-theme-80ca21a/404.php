<?php get_header(); ?>
<div id="content">
	<div id="contentleft">
		<div class="postarea">
			<h1>Not Found, Error 404</h1>
			<p>The page you are looking for no longer exists.</p>
		</div>
	</div>
	<?php get_sidebar()?>
</div>
<!-- The main column ends  -->
<?php get_footer()?>