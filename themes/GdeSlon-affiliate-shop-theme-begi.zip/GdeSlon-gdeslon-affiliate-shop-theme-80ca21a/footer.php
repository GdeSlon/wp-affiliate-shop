<!-- begin footer -->
<div style="clear:both;"></div>
</div>
<div id="footer">
	<div class="footer">
		<p>&copy; <?php echo date("Y"); ?> <a href="<?php echo home_url(); ?>/"><?php bloginfo('name'); ?></a> &middot; Powered by <a href="http://wordpress.org">WordPress</a></p>
	</div>
</div>
<?php wp_footer(); ?>
</body>
</html>